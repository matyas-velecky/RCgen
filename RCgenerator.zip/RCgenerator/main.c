#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

#define MIN_YEAR 1945
#define MAX_YEAR 2053
#define MIN_MD 1
#define MAX_MONTH 12
#define MIN_TRI_NUMBER 0
#define MAX_TRI_NUMBER 999

//spravit gender a dalsi bugy

typedef struct {
    int year;
    int month;
    int day;
    int threeNums;
} COMPONENTS;

typedef struct {
    char id[11];
    COMPONENTS IDComponents;
} ID;

void header() {
    printf("Generator of fictive ID\n");
    printf("-----------------------\n");
}

int input(const int min, const int max) {
    int year;
    int control;
    do {
        printf("Enter year in the interval from %d to %d\n", min, max);
        scanf("%d", &year);
        control = 0;
        while (getchar() != '\n') {
            control++;
        }
        if (control > 0) {
            printf("You didn't enter a number\n");
        }
        if (year > max) {
            printf("You entered a bigger year\n");
            control = 1;
        }
        if (year < min) {
            printf("You entered a smaller year\n");
            control = 1;
        }
    } while (control > 0);
    return year;
}

int genderInput() {
    char gender[6];
    printf("Enter your gender. (the only two working are man and woman, because unfortunately the id works like that)\n");
    scanf("%5s", gender);
    if (strcmp(gender, "man") == 0) {
        return 1;
    }
    if (strcmp(gender, "woman") == 0) {
        return 0;
    } else {
        printf("Wrong input\n");
        return -1;
    }
}

void completion(ID *id) {
    srand((unsigned) time(NULL));
    char tmp[5];
    int genThreeNum;
    itoa(id->IDComponents.year, tmp, 10);
    strncat(id->id, tmp, 2);

    itoa(id->IDComponents.day, tmp, 10);

    if (id->IDComponents.day < 10) {
        strcat(id->id, "0");
        strncat(id->id, tmp, 1);
    } else {
        strncat(id->id, tmp, 2);
    }

    if(genderInput() == 0) {
        itoa(id->IDComponents.month + 50, tmp, 10);
    }else{
        itoa(id->IDComponents.month, tmp, 10);
    }

    if (id->IDComponents.month < 10) {
        strcat(id->id, "0");
        strncat(id->id, tmp, 1);
    } else {
        strncat(id->id, tmp, 2);
    }

    itoa(id->IDComponents.threeNums, tmp, 10);
    strncat(id->id, tmp, 3);

    genThreeNum = atoi(tmp);

    do {
        if (genThreeNum % 11 != 10) {
            itoa(genThreeNum % 11, tmp, 10);
        } else {
            genThreeNum = rand() % 1000;
        }
    } while (genThreeNum % 11 != 10);
    strncat(id->id, tmp, 1);
    printf("%s", id->id);
}

int main(void) {
    ID *id;
    header();
    int largerMonths[7] = {1, 3, 5, 7, 8, 10, 12};
    id->IDComponents.year = input(MIN_YEAR, MAX_YEAR);
    id->IDComponents.month = input(MIN_MD, MAX_MONTH);
    id->IDComponents.day = 0;
    int indexOFlm = 0;
    do {
        if (id->IDComponents.month == largerMonths[indexOFlm]) {
            id->IDComponents.day = input(MIN_MD, 31);
        } else if (id->IDComponents.month == 2) {
            id->IDComponents.day = input(MIN_MD, 29);
        } else {
            id->IDComponents.day = input(MIN_MD, 30);
        }
        indexOFlm++;
    } while (id->IDComponents.day == 0);
    id->IDComponents.threeNums = input(MIN_TRI_NUMBER, MAX_TRI_NUMBER);
    completion(id);
    return 0;
}
