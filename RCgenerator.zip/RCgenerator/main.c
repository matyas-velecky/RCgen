#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

#define MIN_YEAR 1945
#define MAX_YEAR 2053
#define MIN_MD 1
#define MAX_MONTH 12
#define MIN_TRI_NUMBER 0
#define MAX_TRI_NUMBER 999


typedef struct {
    int year;
    int month;
    int day;
    int threeNums;
} COMPONENTS;

typedef struct {
    char id[11];
    COMPONENTS IDComponents;
} ID;

void header() {
    printf("Generator of fictive ID\n");
    printf("-----------------------\n");
}

int input(const int min, const int max, const char *txt) {
    int year;
    int control;
    do {
        printf("Enter %s in the interval from %d to %d\n", txt, min, max);
        scanf("%d", &year);
        control = 0;
        while (getchar() != '\n') {
            control++;
        }
        if (control > 0) {
            printf("You didn't enter a number\n");
        }
        if (year > max) {
            printf("You entered a bigger year\n");
            control = 1;
        }
        if (year < min) {
            printf("You entered a smaller year\n");
            control = 1;
        }
    } while (control > 0);
    return year;
}

int genderInput() {
    char gender[6];
    while (1) {
        printf("Enter your gender (man or woman):\n");
        scanf("%5s", gender);

        while (getchar() != '\n');

        if (strcmp(gender, "man") == 0) {
            return 1;
        } else if (strcmp(gender, "woman") == 0) {
            return 0;
        } else {
            printf("Wrong input, try again.\n");
        }
    }
}


void completion(ID *id, int gender) {
    char tmp[10];
    id->id[0] = '\0';

    sprintf(tmp, "%02d", id->IDComponents.year % 100);
    strcat(id->id, tmp);

    int month = (gender == 0) ? id->IDComponents.month + 50 : id->IDComponents.month;
    sprintf(tmp, "%02d", month);
    strcat(id->id, tmp);

    sprintf(tmp, "%02d", id->IDComponents.day);
    strcat(id->id, tmp);

    sprintf(tmp, "%03d", id->IDComponents.threeNums);
    strcat(id->id, tmp);

    int num = atoi(id->id);
    int control = num % 11;
    sprintf(tmp, "%d", control);
    strcat(id->id, tmp);

    printf("Generated ID: %s\n", id->id);
}

int main(void) {
    srand((unsigned) time(NULL));
    int gender;
    ID id;
    header();
    int largerMonths[7] = {1, 3, 5, 7, 8, 10, 12};
    id.IDComponents.year = input(MIN_YEAR, MAX_YEAR, "year");
    id.IDComponents.month = input(MIN_MD, MAX_MONTH, "month");
    id.IDComponents.day = 0;
    int indexOFlm = 0;
    do {
        if (id.IDComponents.month == largerMonths[indexOFlm]) {
            id.IDComponents.day = input(MIN_MD, 31, "day");
        } else if (id.IDComponents.month == 2) {
            id.IDComponents.day = input(MIN_MD, 29, "day");
        } else {
            id.IDComponents.day = input(MIN_MD, 30, "day");
        }
        indexOFlm++;
    } while (id.IDComponents.day == 0);
    id.IDComponents.threeNums = input(MIN_TRI_NUMBER, MAX_TRI_NUMBER, "tri number");
    gender = genderInput();
    completion(&id, gender);
    return 0;
}
